
<?php

// connection details for MySQL database

$cd_host = "127.0.0.1";
$cd_port = 8889;
$cd_socket = "/Applications/MAMP/tmp/mysql/mysql.sock";

// database name, username and password

$cd_dbname = "companydirectory";
$cd_user = "root";
$cd_password = "root";

?>
